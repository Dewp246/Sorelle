# Product Requirement Document (PRD) & Project Brief: Sorelle Marketplace

---

## 1. Executive Summary & Brand Overview

### 1.1 Brand Identity
- **Nama Platform:** Sorelle (E-Commerce & Artisan Marketplace)
- **Tagline / Visi:** *Marketplace Pilihan Produk Kurasi, Rumah & Dapur, Gaya Hidup Estetik, dan Artisan Lokal.*
- **Karakteristik Visual & Tone of Voice:**
  - **Palet Warna:** Warm Editorial Marketplace (Ivory/Off-white `#FFF8F5`, Sandstone `#F3E7D7`, Terakota `#C96F3B`, Peach Clay `#F4A261`, Earth Charcoal `#2B2523`).
  - **Tipografi:** Playfair Display (Headings, Editorial Elegance) & Plus Jakarta Sans / Inter (Clean UI & Microcopy).
  - **Filosofi Desain:** Menggabungkan kemewahan editorial majalah gaya hidup dengan kenyamanan belanja transaksional modern yang cepat, terpercaya, dan ramah sentuhan (mobile-first).

### 1.2 Target Audiens
1. **Pecinta Estetika & Dekorasi Rumah (Home Living Enthusiasts):** Usia 22–45 tahun yang mencari perlengkapan rumah, aromaterapi, keramik artisan, dan tekstil berkualitas tinggi.
2. **Kolektor & Pembeli Produk Handmade/Artisan:** Menghargai keaslian (*craftsmanship*), cerita brand, dan keterlacakan bahan.
3. **Penyuka Pengalaman Belanja Mulus (Convenience Seekers):** Membutuhkan pelacakan live delivery instan, jaminan garansi retur/proteksi, serta sistem ulasan transparan.

---

## 2. Platform Architecture & Multi-Platform Scope

Sorelle dirancang responsif mencakup dua format perangkat utama:
- **Desktop Web (1440px / Large Screen):** Fokus pada eksplorasi visual luas, editorial banners, filter multi-aspek, dan checkout instan dengan integrasi Midtrans Snap.
- **Mobile Web / App (390px / iOS & Android standard):** Navigasi bottom-bar 5 tab terarah (*Beranda, Eksplorasi, Notifikasi, Keranjang, Akun*), flow transaksi ramah satu jempol, live GPS tracking kurir, dan bottom sheet interaktif.

---

## 3. End-to-End User Flow & Inverted Milestone Map

Alur perjalanan pengguna terintegrasi mencakup 7 tahapan utama:
```
[1. Discovery & Kategori] ➔ [2. Detail Produk (PDP)] ➔ [3. Keranjang & Diskon]
           ➔ [4. Checkout Midtrans] ➔ [5. Live Courier Tracking & Tiba di Rumah]
                     ➔ [6. Modal Konfirmasi & Foto Bukti] ➔ [7. Ulasan & Gamifikasi Koin]
```

### Tahap 1: Discovery & Beranda
- **Desktop:** Hero banner kurasi, filter kategori interaktif (*Rumah & Dapur, Perawatan Diri, Artisan Lokal*), badge flash sale & rekomendasi personal.
- **Mobile:** Top search bar mengambang, carousel banner bertema, grid produk 2 kolom adaptif dengan tag *Favorit* dan *Handmade*.

### Tahap 2: Detail Produk (PDP)
- Galeri foto multi-sudut resolusi tinggi dengan zoom.
- Pemilihan varian (ukuran, warna, kelengkapan tatakan kayu).
- Garansi Sorelle Care (jaminan barang anti-pecah 100%).
- Penilaian ulasan pembeli dengan filter media (foto/video).
- Sticky CTA: *"Tambah ke Keranjang"* & *"Beli Sekarang"*.

### Tahap 3: Keranjang Belanja
- Pengelompokan pesanan berdasarkan toko/merchant artisan.
- Penggunaan kupon diskon & opsi penukaran Koin Sorelle.
- Proteksi pengiriman opsional (*bubble wrap biodegradable* + asuransi).

### Tahap 4: Checkout & Pembayaran Terintegrasi
- Alamat multi-lokasi (Rumah, Kantor) dengan pinpoint peta presisi.
- Pilihan logistik fleksibel (Instant, Same-Day, Reguler SiCepat/J&T).
- Gateway pembayaran: Midtrans Snap terintegrasi (BCA/Mandiri VA, GoPay, QRIS, Kartu Kredit).

### Tahap 5: Pelacakan Kurir Real-Time (Live Map Tracking)
- **State 1: Dalam Perjalanan (In-Transit):**
  - Rute GPS langsung dari hub logistik ke alamat penerima.
  - Estimasi waktu tiba (ETA) dinamis & indikator sisa menit.
  - Kartu profil pengemudi (*Nama, foto, plat nomor sepeda motor, rating, tombol Telp & WhatsApp*).
- **State 2: Kurir Tiba di Rumah (Arrived):**
  - Pin kurir tiba di pagar rumah penerima.
  - Quick-action pesan kilat (*"Saya segera keluar"*, *"Tolong taruh di teras"*, *"Titip sekuriti"*).
  - Tombol aksi: *"Konfirmasi Terima Barang"* aktif.

### Tahap 6: Verifikasi Penerimaan & Modal Foto Bukti
- Bottom-sheet verifikasi barang diterima.
- Unggah foto bukti paket (*Proof of Delivery: segel luar & isi botol/produk*).
- Checkbox kondisi fisik paket (utuh sempurna, sedikit penyok, rusak/komplain).
- Rating kilat pelayanan kurir.
- Pelepasan dana otomatis dari *escrow* ke pihak merchant/penjual.

### Tahap 7: Selesai, Ulasan, & Gamifikasi Koin
- **Layar Pesanan Berhasil Diselesaikan:**
  - Apresiasi penyelesaian transaksi & kredit loyalitas (+500 Koin Sorelle).
  - Indikator jenjang keanggotaan (Progress tahunan menuju *Sorelle Platinum*).
  - Rekomendasi pelengkap (*"Mungkin Anda Juga Suka"*).
  - Unduh e-Receipt bukti pembayaran (PDF).
- **Formulir Ulasan Komprehensif:**
  - Gamifikasi imbalan: Maks. +250 Koin (Rating terinci, 1 foto asli, 1 video estetik).
  - Tag impresi instan (*Aroma Menenangkan, Kualitas Kayu Premium, Kemasan Aman*).
  - Multi-aspect rating (Wangi & ketahanan, material tatakan kayu, desain botol).
  - Pengaturan privasi (anonimisasi nama `S***a` & opsi publikasi ke feed Komunitas).

---

## 4. Technical & Design System Specifications

### 4.1 Design Tokens (Tokens Reference: `Warm Editorial Marketplace`)
- **Primary Brand Color:** `#C96F3B` (Terracotta Accent) / `#F4A261` (Warm Amber Glow)
- **Neutral Light:** `#FFF8F5` (Surface Base), `#FFF1EA` (Container Low), `#E7D7CE` (Border/Dim)
- **Text & Contrast:** `#2B2523` (High Contrast Dark Slate/Mocha), `#756A63` (Muted Label)
- **Success & Status:** `#2E7D32` (Delivery Complete / Shield Verified), `#E65100` (Urgent / Active Tracking)
- **Border Radius:** `rounded-2xl` (16px) untuk card container, `rounded-full` untuk pills & badge.

### 4.2 Security & Trust Enablers
- **Escrow Guarantee:** Pembayaran ditahan di sistem Sorelle sampai pelanggan menekan verifikasi terima paket atau batas waktu 2x24 jam berakhir.
- **Sorelle Care Proteksi Pecah:** Penggantian instan 100% jika foto unboxing membuktikan produk pecah dalam pengiriman.
- **Transparansi Logistik:** Kolaborasi API kurir untuk live telemetry data & nomor resi real-time.

---

## 5. Rencana Pengembangan Lanjutan (Roadmap)
1. **Fase 1 (MVP - Current Scope):** Discovery produk, checkout, pelacakan live kurir, modal foto bukti, dan sistem review gamifikasi.
2. **Fase 2 (Social & Merchant Portal):** Feed inspirasi komunitas dekorasi rumah (*Shoppable Lookbook*), dashboard merchant khusus artisan, dan fitur pre-order custom keramik.
3. **Fase 3 (Personalized AI Assistant):** Konsultasi kurasi dekorasi ruangan berbasis foto (*Visual Search / Room AI Matcher*) di dalam aplikasi Sorelle.
